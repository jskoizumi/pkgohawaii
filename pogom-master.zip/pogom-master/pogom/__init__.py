#!/usr/bin/python
# -*- coding: utf-8 -*-

config = {
    'LOCALE': 'en',
    'LOCALES_DIR': 'static/locales',
    'ROOT_PATH': None,
    'GOOGLEMAPS_KEY': 'GMAPS KEY HERE'
}
